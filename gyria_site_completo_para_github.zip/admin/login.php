<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $user = $_POST['usuario'] ?? '';
  $pass = $_POST['senha'] ?? '';
  $senha_segura = 'GyriaMus1cal@2025';
  if ($user === 'admin' && $pass === $senha_segura) {
    session_regenerate_id(true); // Prevê fixação de sessão
    $_SESSION['admin'] = true;
    header('Location: painel.php');
    exit;
  } else {
    $erro = 'Usuário ou senha incorretos';
  }
}
?>
<form method="POST">
  <h2>Login Administrador</h2>
  <?php if (!empty($erro)) echo "<p style='color:red;'>$erro</p>"; ?>
  <input name="usuario" placeholder="Usuário" required><br>
  <input name="senha" type="password" placeholder="Senha" required><br>
  <button type="submit">Entrar</button>
</form>