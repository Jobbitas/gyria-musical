<?php
session_start();
if (!isset($_SESSION['admin'])) {
  header('Location: login.php');
  exit;
}
?>
<h2>Painel do Administrador</h2>
<p><a href="logout.php">Sair</a></p>
<ul>
  <li><a href="produtos.html">Gerenciar Produtos</a></li>
  <li><a href="faturamento.html">Ver Faturamento</a></li>
</ul>